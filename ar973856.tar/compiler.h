#ifndef COMPILER_H
#define COMPILER_H

void convertCode(Instruction instruction);

#endif
